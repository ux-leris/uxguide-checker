<?php
  class Enviroment {
    private static $baseURL = "http://localhost/applications/uxguide-checker";

    public static function getBaseURL() {
      return self::$baseURL;
    }
  }
?>