<?php
    function getColors()
    {
        return [
            "#008ffb",
            "#00e396",
            "#feb019",
            "#ff4560",
            "#775dd0",
            "#fc8a56",
            "#ff94fd",
            "#69d2e7",
            "#1b998b",
            "#a5978b"
        ];
    }
?>