<?php
    function getPatterns()
    {
        return [
            "plus",
            "diamond",
            "dash",
            "box",
            "disc",
            "ring",
            "line",
            "weave",
            "zigzag",
            "triangle"
        ];
    }
?>