<nav class="navbar navbar-expand-lg navbar-light">
  <span class="navbar-brand text-light">
    UX Guide Checker
  </span>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavDropdown">
    <ul class="navbar-nav">
        <li class="nav-item">
        <a class="nav-link text-light" href="../../index.php">
          Homepage
        </a>	
        </li>
    </ul>
    <ul class="navbar-nav ml-auto">
        <li class="nav-item">
        <a class="nav-link text-light" href="../controllers/index/logOut.php">
            Log out
        </a>						
        </li>
    </ul>
  </div>
</nav>